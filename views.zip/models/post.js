// Esquema Posts

const mongoose = require('mongoose');

const PostSchema = new mongoose.Schema({
  nomPost: {
    type: String,
    required: true
  },
  descriptionPost: {
    type: String
  }
});

const Post = mongoose.model('Post', PostSchema);

module.exports = Post;
