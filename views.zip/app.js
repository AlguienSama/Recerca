const express = require('express');
const mongoose = require('mongoose');
const passport = require('passport');
const flash = require('connect-flash');
const session = require('express-session');
const bodyParser = require('body-parser');

const app = express();

// Passport Config
require('./config/passport')(passport);

// Connect to MongoDB
// mongoose.connect('mongodb://MarcFont:marcfont24.@ds039504.mlab.com:39504/prova1', { useNewUrlParser: true })
mongoose.connect('mongodb://localhost:27017/usuarios', { useNewUrlParser: true })
    .then(() => console.log('Contectat a la BD!'))
    .catch(err => console.error('Error al conectar a la BD', err));

// Settings
app.set('view engine', 'ejs');


// Middlewares
app.use(express.urlencoded({ extended: true }));

app.use(
  session({
    secret: 'secret',
    resave: true,
    saveUninitialized: true
  })
);

app.use(passport.initialize());
app.use(passport.session());

app.use(flash());

app.use(bodyParser.json())
app.use(bodyParser.urlencoded({extended: true}));

app.use(function(req, res, next) {
  res.locals.success_msg = req.flash('success_msg');
  res.locals.error_msg = req.flash('error_msg');
  res.locals.error = req.flash('error');
  res.locals.user = req.user || null;
  next();
});


// Routes
app.use('/', require('./routes/index.js'));
app.use('/users', require('./routes/users.js'));



const PORT = process.env.PORT || 4000;

app.listen(PORT, console.log(`Server started on port ${PORT}`));
