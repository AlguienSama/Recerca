const express = require('express');
const router = express.Router();

const { ensureAuthenticated, forwardAuthenticated } = require('../config/auth');


// Rutes
router.get('/', async (req, res) => {
  const posts = await Post.find({})
  res.render('index', {
    posts
  })
});

router.get('/users/login', (req, res) => res.render('login'));
router.get('/users/register', (req, res) => res.render('register'));

const Post = require('../models/post');

router.get('/app/new', ensureAuthenticated, (req, res) => res.render('newPost', {
  user: req.user
}));
router.post('/app/store', (req, res) => {
  Post.create(req.body,(error, post) => {
    res.redirect('/')
  })
});

router.get('/posts/:page', (req, res) => {
  let perPage = 5;
  let page = req.params.page || 1;

  Post
    .find({})
    .skip((perPage * page) - perPage)
    .limit(perPage)
    .exec((err, products) => {
      Post.countDocuments((err, count) => {
        if (err) return next(err);
        res.render('posts/pages', {
          Post,
          current: page,
          pages: Math.ceil(count / perPage)
        });
      })
    })
});


router.get('/post/:id', async (req, res) => {
    const post = await Post.findById(req.params.id)
    res.render('post', {
        post
    })
});




router.get('/dashboard', ensureAuthenticated, (req, res) => res.render('dashboard', {
  user: req.user
}));



module.exports = router;
